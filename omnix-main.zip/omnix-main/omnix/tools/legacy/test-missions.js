import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabase = createClient(process.env.VITE_SUPABASE_URL, process.env.VITE_SUPABASE_ANON_KEY);
async function run() {
  try {
    const { data, error } = await supabase.from('missions').select('*').limit(1);
    console.log(error || 'Success');
  } catch (e) {
    console.log('Exception:', e);
  }
}
run();
